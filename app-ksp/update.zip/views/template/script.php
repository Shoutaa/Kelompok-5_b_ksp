<script src="<?php echo base_url()?>assets/theme/scripts/DataTables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>assets/theme/scripts/DataTables/media/js/DT_bootstrap.js"></script>
<!-- JQueryUI v1.9.2 -->
	<script src="<?php echo base_url()?>assets/theme/scripts/jquery-ui-1.9.2.custom/js/jquery-ui-1.9.2.custom.min.js"></script>
	
	<!-- JQueryUI Touch Punch -->
	<!-- small hack that enables the use of touch events on sites using the jQuery UI user interface library -->
	<script src="<?php echo base_url()?>assets/theme/scripts/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	
	<!-- MiniColors -->
	<script src="<?php echo base_url()?>assets/theme/scripts/jquery-miniColors/jquery.miniColors.js"></script>
	
	<!-- Themer -->
	<script>
	var themerPrimaryColor = '#71c39a';
	</script>
	<script src="<?php echo base_url()?>assets/theme/scripts/jquery.cookie.js"></script>
	<script src="<?php echo base_url()?>assets/theme/scripts/themer.js"></script>
	
	
	 <!-- <script type="text/javascript" src="https://www.google.com/jsapi"></script> -->

		<!-- Sparkline -->
	<script src="<?php echo base_url()?>assets/theme/scripts/jquery.sparkline.min.js" type="text/javascript"></script>

		
	<!--  Flot (Charts) JS -->
	<script src="<?php echo base_url()?>assets/theme/scripts/flot/jquery.flot.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets/theme/scripts/flot/jquery.flot.pie.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets/theme/scripts/flot/jquery.flot.tooltip.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets/theme/scripts/flot/jquery.flot.selection.js"></script>
	<script src="<?php echo base_url()?>assets/theme/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets/theme/scripts/flot/jquery.flot.orderBars.js" type="text/javascript"></script>
	
		
	
	
	
	<!-- Resize Script -->
	<script src="<?php echo base_url()?>assets/theme/scripts/jquery.ba-resize.js"></script>
	
	<!-- Uniform -->
	<script src="<?php echo base_url()?>assets/theme/scripts/pixelmatrix-uniform/jquery.uniform.min.js"></script>
	
	<!-- Bootstrap Script -->
	<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js"></script>
	
	<!-- Bootstrap Extended -->
	<script src="<?php echo base_url()?>assets/bootstrap/extend/bootstrap-select/bootstrap-select.js"></script>
	<script src="<?php echo base_url()?>assets/bootstrap/extend/bootstrap-toggle-buttons/static/js/jquery.toggle.buttons.js"></script>
	<script src="<?php echo base_url()?>assets/bootstrap/extend/bootstrap-hover-dropdown/twitter-bootstrap-hover-dropdown.min.js"></script>
	<script src="<?php echo base_url()?>assets/bootstrap/extend/jasny-bootstrap/js/jasny-bootstrap.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets/bootstrap/extend/jasny-bootstrap/js/bootstrap-fileupload.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets/bootstrap/extend/bootbox.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets/bootstrap/extend/bootstrap-wysihtml5/js/wysihtml5-0.3.0_rc2.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets/bootstrap/extend/bootstrap-wysihtml5/js/bootstrap-wysihtml5-0.0.2.js" type="text/javascript"></script>
	
	<!-- Custom Onload Script -->
	<script src="<?php echo base_url()?>assets/theme/scripts/load.js"></script>

</body>
</html>